import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MaListView(),
    );
  }
}

class MaListView extends StatelessWidget {
  final List desc = [
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
    "10",
    "11",
    "12"
  ];
  final List mois = [
    "Janvier",
    "Février",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Août",
    "Septembre",
    "Octobre",
    "Novembre",
    "Décembre"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List 2"),
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
                title: Text(mois[index], style: TextStyle(fontSize: 30)),
                subtitle: Text('Numéro ' + desc[index]),
                leading: CircleAvatar(
                  child: Text(mois[index][0], style: TextStyle(fontSize: 20)),
                )),
          );
        },
        itemCount: mois.length,
      ),
    );
  }
}
