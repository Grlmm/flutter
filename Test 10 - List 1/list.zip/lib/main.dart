import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(
              title: Text("list test 1"),
            ),
            body: ListView(
              padding: const EdgeInsets.all(8),
              children: <Widget>[
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('tacos')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('piza')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('burger')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('pita')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('sandwich')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('pâtes')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('frites')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('salade')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('boisson')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('fourniture')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('menu')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('Formule duo')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[100],
                  child: const Center(child: Text('Formule trio')),
                ),
                Container(
                  height: 50,
                  color: Colors.blue[300],
                  child: const Center(child: Text('Menu enfant')),
                ),
              ],
            )));
  }
}
