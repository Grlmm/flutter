import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Data Share',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? _result;
  final textEditingController = TextEditingController(text: "Accueil");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dta Share'),
      ),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
          TextField(
            controller: textEditingController,
            obscureText: false,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'info',
            ),
          ),
          ButtonBar(
            children: <Widget>[
              OutlinedButton(
                onPressed: () => goAhead(true),
                child: Text("valider"),
              ),
            ],
          ),
          Text(_result != null ? "information saisie: '$_result'" : "")
        ]),
      ),
    );
  }

  Future<void> goAhead(bool standardType) async {
    var result;
    if (standardType) {
      result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SecondPage(textEditingController.text),
          ));
    } else {
      result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SecondPage(),
            settings: RouteSettings(
              arguments: textEditingController.text,
            ),
          ));
    }

    if (result != null) {
      setState(() {
        _result = result;
      });
    }
  }
}

class SecondPage extends StatelessWidget {
  final String? _title;
  final textEditingController = TextEditingController(text: "Texte");
  SecondPage([this._title]);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ecran Info'),
      ),
      body: Center(
          child: Column(
        children: <Widget>[
          Text("Info enregistré: $_title"),
          TextField(
            controller: textEditingController,
            obscureText: false,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'info',
            ),
          ),
          ButtonBar(
            children: <Widget>[
              OutlinedButton(
                onPressed: () => returnWithValue(context),
                child: Text("Enregistré"),
              ),
            ],
          ),
        ],
      )),
    );
  }

  void returnWithValue(BuildContext context) {
    Navigator.pop(context, textEditingController.text);
  }
}
